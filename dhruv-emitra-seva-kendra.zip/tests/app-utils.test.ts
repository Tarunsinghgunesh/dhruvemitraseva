import { describe, it, expect } from "vitest";
import {
  isValidMobileNumber,
  formatMobileNumber,
  isValidRequestId,
  generateUPIQRCode,
  getServiceIcon,
  truncateText,
  getInitials,
} from "../lib/app-utils";

describe("App Utils", () => {
  describe("isValidMobileNumber", () => {
    it("should validate correct 10-digit mobile numbers", () => {
      expect(isValidMobileNumber("9079368240")).toBe(true);
      expect(isValidMobileNumber("9876543210")).toBe(true);
    });

    it("should reject invalid mobile numbers", () => {
      expect(isValidMobileNumber("123")).toBe(false);
      expect(isValidMobileNumber("12345678901")).toBe(false);
      expect(isValidMobileNumber("abc1234567")).toBe(false);
    });

    it("should handle formatted mobile numbers", () => {
      expect(isValidMobileNumber("+91-9079368240")).toBe(true);
      expect(isValidMobileNumber("(907) 936-8240")).toBe(true);
    });
  });

  describe("formatMobileNumber", () => {
    it("should format 10-digit mobile numbers with +91 prefix", () => {
      expect(formatMobileNumber("9079368240")).toBe("+919079368240");
      expect(formatMobileNumber("9876543210")).toBe("+919876543210");
    });

    it("should handle already formatted numbers", () => {
      expect(formatMobileNumber("+91-9079368240")).toBe("+919079368240");
    });

    it("should return original if not 10 digits", () => {
      expect(formatMobileNumber("123")).toBe("123");
    });
  });

  describe("isValidRequestId", () => {
    it("should validate request IDs with at least 3 characters", () => {
      expect(isValidRequestId("REQ123")).toBe(true);
      expect(isValidRequestId("ABC")).toBe(true);
    });

    it("should reject short request IDs", () => {
      expect(isValidRequestId("AB")).toBe(false);
      expect(isValidRequestId("")).toBe(false);
    });
  });

  describe("generateUPIQRCode", () => {
    it("should generate valid QR code URL", () => {
      const url = generateUPIQRCode("tarun.8240@ptyes", "Tarun Singh");
      expect(url).toContain("api.qrserver.com");
      expect(url).toContain("upi://pay");
      expect(url).toContain("tarun.8240@ptyes");
    });

    it("should encode special characters in name", () => {
      const url = generateUPIQRCode("test@upi", "John Doe");
      expect(url).toContain("John%20Doe");
    });
  });

  describe("getServiceIcon", () => {
    it("should return correct icons for services", () => {
      expect(getServiceIcon("Aadhaar Update & Print")).toBe("🆔");
      expect(getServiceIcon("PAN Card (New / Correction)")).toBe("💳");
      expect(getServiceIcon("Birth & Death Certificate")).toBe("👶");
    });

    it("should return default icon for unknown service", () => {
      expect(getServiceIcon("Unknown Service")).toBe("📋");
    });
  });

  describe("truncateText", () => {
    it("should truncate text longer than max length", () => {
      const text = "This is a very long text that needs truncation";
      expect(truncateText(text, 10)).toBe("This is...");
    });

    it("should not truncate text shorter than max length", () => {
      const text = "Short";
      expect(truncateText(text, 10)).toBe("Short");
    });
  });

  describe("getInitials", () => {
    it("should extract initials from names", () => {
      expect(getInitials("Tarun Singh")).toBe("TS");
      expect(getInitials("John Doe")).toBe("JD");
    });

    it("should handle single names", () => {
      expect(getInitials("Tarun")).toBe("T");
    });

    it("should handle multiple word names", () => {
      expect(getInitials("John Paul Smith")).toBe("JP");
    });
  });
});
