# Dhruv E-Mitra Seva Kendra - Mobile App Design

## App Overview

A professional, government-service-style digital service center app for Android. The app provides quick access to government services, bill payments, and support channels with a modern blue-teal gradient theme.

---

## Screen List

1. **Home Screen** - Main entry point with navigation to all services
2. **Services Screen** - Grid/list of available government services
3. **Service Detail Screen** - Service information and Google Form link
4. **Payment Screen** - UPI payment interface with QR code
5. **Status Screen** - Check application status by mobile number or request ID
6. **Settings Screen** - App information and preferences

---

## Primary Content and Functionality

### Screen 1: Home Screen
**Purpose:** Main dashboard with quick access to all major features

**Content:**
- App logo at the top (square icon)
- Title: "Dhruv E-Mitra Seva Kendra"
- Tagline: "Fast • Reliable • Secure"
- Six primary action buttons:
  - Apply for Services (blue button)
  - Check Status (teal button)
  - Make Payment (green button)
  - WhatsApp Support (green button)
  - Visit Website (blue button)
  - Location (map pin button)
- Footer with owner info: "Tarun Singh | Brij Nagar, Bharatpur"

**Functionality:**
- Each button navigates to its respective section
- Smooth animations on button press
- Internet connectivity check before navigation

### Screen 2: Services Screen
**Purpose:** Display all available government services

**Content:**
- Header with back button and "Services" title
- Service cards in a grid (2 columns) or scrollable list:
  1. Aadhaar Update & Print
  2. PAN Card (New / Correction)
  3. Income / Caste / Domicile Certificate
  4. Birth & Death Certificate
  5. Ayushman Card
  6. E-Shram Registration
  7. Scholarship & Government Job Forms
  8. Electricity / Water / Gas Bill Payment
  9. Mobile & DTH Recharge
  10. Online Form Filling
  11. Other Services
- Each card shows service icon and name

**Functionality:**
- Tap any service card to open Google Form with service pre-selected
- Loading indicator while opening form
- Error handling if form link fails

### Screen 3: Payment Screen
**Purpose:** Display payment options and process UPI payments

**Content:**
- Header with back button and "Make Payment" title
- UPI ID display: "tarun.8240@ptyes"
- "Pay Now" button (primary action)
- QR code image for manual scanning
- Payment amount input field (optional)
- Payment history or recent transactions (if applicable)

**Functionality:**
- "Pay Now" button triggers UPI intent
- QR code can be scanned by other apps
- Haptic feedback on button press
- Success/error messages after payment attempt

### Screen 4: Status Screen
**Purpose:** Check application status

**Content:**
- Header with back button and "Check Status" title
- Input field: "Enter Mobile Number or Request ID"
- "Check Status" button
- Status message display area
- Contact WhatsApp link

**Functionality:**
- Accept mobile number or request ID input
- Show predefined status message: "Your application is under process. Please contact WhatsApp for updates."
- WhatsApp link for direct support

### Screen 5: WhatsApp Support
**Purpose:** Direct WhatsApp communication

**Content:**
- Header with back button
- WhatsApp contact information
- "Chat on WhatsApp" button
- Predefined message template (optional)

**Functionality:**
- Opens WhatsApp chat with +919079368240
- Prefilled message for context

### Screen 6: Website Screen
**Purpose:** Display website or open in browser

**Content:**
- Header with back button
- Website URL: https://tarunsinghgunesh.github.io/dhruvemitrasevakendra/
- "Open in Browser" button
- Website preview (if using WebView)

**Functionality:**
- Opens website in in-app browser or system browser

### Screen 7: Location Screen
**Purpose:** Display service center location

**Content:**
- Header with back button
- Google Maps embedded or button to open
- Location: Brij Nagar, Bharatpur (27.2067169, 77.5246241)
- Address and contact information

**Functionality:**
- Opens Google Maps with location pinned
- Shows directions option

---

## Key User Flows

### Flow 1: Apply for Service
1. User taps "Apply for Services" on Home
2. Services Screen displays all available services
3. User taps a service card
4. Google Form opens with service pre-selected
5. User fills and submits form
6. Success message shown

### Flow 2: Make Payment
1. User taps "Make Payment" on Home
2. Payment Screen displays UPI ID and QR code
3. User taps "Pay Now" button
4. UPI app opens (Google Pay, PhonePe, etc.)
5. User completes payment
6. Returns to app with success confirmation

### Flow 3: Check Status
1. User taps "Check Status" on Home
2. Status Screen displays input field
3. User enters mobile number or request ID
4. Taps "Check Status" button
5. Status message displayed
6. Option to contact WhatsApp for updates

### Flow 4: Get Support
1. User taps "WhatsApp Support" on Home
2. WhatsApp opens with service center contact
3. User can chat directly with support team

### Flow 5: Visit Website
1. User taps "Visit Website" on Home
2. Website opens in browser
3. User can view more information

### Flow 6: View Location
1. User taps "Location" on Home
2. Google Maps opens with service center pinned
3. User can view directions and nearby places

---

## Color Choices

**Primary Gradient:** Blue to Teal
- Blue: `#0066CC` (primary actions)
- Teal: `#00AA88` (secondary actions)
- Dark Blue: `#003D99` (pressed state)
- Light Teal: `#33CCBB` (hover state)

**Neutral Colors:**
- Background: `#FFFFFF` (light mode) / `#0F1419` (dark mode)
- Surface: `#F5F5F5` (light mode) / `#1A1F26` (dark mode)
- Text Primary: `#1A1A1A` (light mode) / `#FFFFFF` (dark mode)
- Text Secondary: `#666666` (light mode) / `#AAAAAA` (dark mode)
- Border: `#DDDDDD` (light mode) / `#333333` (dark mode)

**Status Colors:**
- Success: `#22C55E` (green)
- Warning: `#F59E0B` (orange)
- Error: `#EF4444` (red)
- Info: `#3B82F6` (blue)

**Button Styles:**
- Primary Button: Blue gradient with white text, rounded corners
- Secondary Button: Teal gradient with white text
- Tertiary Button: Outline style with blue border
- Disabled Button: Gray with reduced opacity

---

## Design Principles

1. **Mobile-First:** All layouts optimized for portrait orientation (9:16 aspect ratio)
2. **One-Handed Usage:** Primary actions placed in lower half of screen
3. **Accessibility:** Large touch targets (minimum 48x48 dp), high contrast text
4. **Performance:** Lightweight, fast-loading, minimal animations
5. **Professional:** Government service style with clean typography and spacing
6. **Responsive:** Works seamlessly on all Android device sizes
7. **Offline Handling:** Clear messages when internet is unavailable
8. **Loading States:** Visible indicators for all async operations

---

## Typography

- **Headings:** Inter Bold, 24-28 sp
- **Subheadings:** Inter SemiBold, 18-20 sp
- **Body Text:** Inter Regular, 14-16 sp
- **Small Text:** Inter Regular, 12-13 sp
- **Button Text:** Inter SemiBold, 16 sp

---

## Spacing & Layout

- **Screen Padding:** 16 dp horizontal, 12 dp vertical
- **Component Spacing:** 12-16 dp between sections
- **Card Padding:** 12 dp
- **Button Height:** 48 dp
- **Border Radius:** 8-12 dp for cards, 24 dp for buttons

---

## Animations

- **Button Press:** Scale 0.97 with 80ms duration
- **Screen Transition:** Fade in 200ms
- **Loading Spinner:** Continuous rotation
- **Toast Messages:** Slide up 300ms, auto-dismiss after 3 seconds
- **Service Cards:** Subtle shadow on press

---

## Offline Handling

- Check internet connectivity before opening external links
- Show "Internet Required" toast if offline
- Cache service list locally
- Provide offline-friendly error messages

---

## Loading & Error States

- **Loading:** Centered spinner with "Loading..." text
- **Error:** Red alert box with error message and retry button
- **Success:** Green checkmark with success message
- **Empty State:** "No services available" message with refresh button
